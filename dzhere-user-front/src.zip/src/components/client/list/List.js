// Custom Navigation Drawer / Sidebar with Image and Icon in Menu Options
// https://aboutreact.com/custom-navigation-drawer-sidebar-with-image-and-icon-in-menu-options/

// import * as React from 'react';
// import { Button, View, Text, SafeAreaView } from 'react-native';

// const List = ({ navigation }) => {
//   return (
//         <View
//           style={{
//             flex: 1,
//             alignItems: 'center',
//             justifyContent: 'center',
//           }}>
//           <Text
//             style={{
//               fontSize: 25,
//               textAlign: 'center',
//               marginBottom: 16,
//             }}>
//             지난 출석 보기
//           </Text>
//           <Button
//             title="오늘의 출석"
//             onPress={() => navigation.navigate('CheckPage')}
//           />
//           <Button
//             title="Go to Third Page"
//             onPress={() => navigation.navigate('ThirdPage')}
//           />
//         </View>
//   );
// };

// export default List;
