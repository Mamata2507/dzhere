import React, { useEffect, useState } from 'react'
import moment from 'moment';
import { useDispatch, useSelector } from 'react-redux';
import { Contents } from '../../../components/client/check/CheckLayout';
import { loadClassList } from '../../../modules/client/check/check';


const CheckContainer = () => {
    const dispatch = useDispatch();
    const [classes, setClasses] = useState({});
    const classList = useSelector(({ check }) => check.classList);
    
    // 출석 시간 저장 state
    const [checkStartTime, setCheckStartTime] = useState({});
    const [checkEndTime, setCheckEndTime] = useState({});

    // 출석 버튼 이벤트
    const onPressStartTime = () => {        
        const ID = Date.now().toString();
        const nowTime = moment().format('YYYY-MM-DD hh:mm:ss');
        const newCheckObject = {
            [ID] : {id: ID, time: nowTime}
        };
        (checkStartTime==='')? setCheckStartTime(newCheckObject) : setCheckEndTime(newCheckObject);
        console.log(checkStartTime);
        console.log(checkEndTime);
        
    }

    // 수업 목록 load
    useEffect(()=>{
        console.log('class load useEffes');
        dispatch(loadClassList());
        console.log('result :'+classList);
    },[])


    return (
        <Contents
            onPressStartTime = {onPressStartTime}
        />
    );
}

export default CheckContainer;