import { createAction, handleActions } from 'redux-actions';
import createRequestSaga, {createRequestActionTypes} from '../../../lib/api/createRequestSaga';
import * as checkAPI from '../../../lib/api/check/check';

// Actions
// 수업
export const [CLASS_LOAD, CLASS_LOAD_SUCCESS, CLASS_LOAD_FAIL] = createRequestActionTypes('class/CLASS_LOAD');
// 출석
const CHECK_LOAD = 'check/CHECK_LOAD';
const CHECK_INSERT = 'check/CHECK_INSERT';

// Reducers
export const loadClassList = createAction(CLASS_LOAD);
// 출석
export const loadCheck = createAction(CHECK_LOAD, id => id);
export const insertCheck = createAction(CHECK_INSERT);

// saga 생성
const classListSaga = createRequestSaga(CLASS_LOAD, checkAPI.loadClasses);

export function* checkSaga() {
    yield takeLatest(CLASS_LOAD, classListSaga);
}

const initState = {
    checktime : {
        checkStart : false,
        checkStartTime : '',
        checkEnd : false,
        checkEndTime : '',
    },
    classList : [],
    
}

export const check = handleActions(
    {
        [CLASS_LOAD_SUCCESS]: (state, {payload: classes})=>({
            ...state,
            classList:classes,
        }),
        [CHECK_LOAD]: (state, {payload: data}) => ({

        }),
        [CHECK_INSERT]: (state, {payload: data})=>({
            
        }),
    },initState
)