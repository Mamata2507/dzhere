import { combineReducers } from 'redux';
import loading from './loading';
import {check, checkSaga} from './check/check';
import {external} from './external/external';
import { all } from '@redux-saga/core/effects';

export const rootReducer = combineReducers({
    external,
    check,
    loading,
  });

export function* rootSaga() {
  yield all(checkSaga());
}
