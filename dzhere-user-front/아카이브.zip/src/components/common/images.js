import CheckBoxOutline from '../../../assets/external/check_box_outline.png';
import CheckBox from '../../../assets/external/check_box.png';
import DeleteForever from '../../../assets/external/delete_forever.png';

export const images = {
  // uncompleted: CheckBoxOutline,
  // completed: CheckBox,
  delete: DeleteForever,
};