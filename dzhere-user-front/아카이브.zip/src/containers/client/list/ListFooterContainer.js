import React from 'react'
import { Footer } from '../../../components/client/list/ListLayout'

export default function ListFooterContainer() {
    return (
        <Footer
        
        />
    )
}
